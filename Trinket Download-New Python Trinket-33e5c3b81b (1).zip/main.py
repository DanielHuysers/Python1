
highest = 0
lowest = 10
total = 0
counter = 0
overallav = 0
for i in range(5):
  score = float(input('enter your scores'))
  while score < 0 or score > 10:
    print 'invalid try again'
    score = float(input('enter your score '))
  total = total+score
  if score > highest:
    highest = score
  if score < lowest:
    lowest = score
  print highest,lowest
print total,'is the total'
av = (total - highest - lowest)/3
print av,'is the average'
counter =counter+1
print counter

answer = str(input('any more people??'))
while answer == "y" or answer == "Y":
  highest = 0
  lowest = 10
  total = 0
  for i in range(5):
    score = float(input('enter your scores'))
    while score < 0 or score > 10:
      print 'invalid try again'
      score = float(input('enter your score '))
    total = total+score
    if score > highest:
      highest = score
    if score < lowest:
      lowest = score
    print highest,lowest
  print total,'is the total'
  av = (total - highest - lowest)/3
  print av,'is the average'
  counter =counter+1
  print counter
  overallav = (overallav + av)/counter
  print 'overall average so far is', overallav
  answer = str(input('any more people??'))
  



  
